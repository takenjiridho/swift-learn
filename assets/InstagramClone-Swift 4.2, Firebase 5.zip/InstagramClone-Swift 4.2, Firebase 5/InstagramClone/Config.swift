//
//  Config.swift
//  InstagramClone
//
//  Created by The Zero2Launch Team on 12/17/16.
//  Copyright © 2016 The Zero2Launch Team. All rights reserved.
//

import Foundation
struct Config {
    static var STORAGE_ROOF_REF = "gs://instagramclone-fc544.appspot.com"
}
